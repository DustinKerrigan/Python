HOW TO RUN PROJECT:

Press run from search.py file. 

To run desired search algorithm, uncomment the res_path assignment to function call that is needed.

If you would like to run with custom unclosures/turfs, modify the paths in the epolygons and tpolygons assignments to
'TestingGrid/myenclosures.txt' and 'TestingGrid/myturfs.txt' respectively. 