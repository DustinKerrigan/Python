from utils import *
from grid import *

def dfs(source,dest,epolygons):
    frontier = Stack()
    frontier.push((source,[source]))
    visited = set() #takes place of isCycle()
    expanded = 0
    while not frontier.isEmpty():
        expanded +=1
        node, path = frontier.pop()
        if node == dest:
            print(expanded)
            return path
        for child in expand(node, epolygons):
            if child.to_tuple() not in visited:
                visited.add(child.to_tuple())
                frontier.push((child, path + [child]))
    return None

def bfs(source,dest,epolygons):
    node = source
    if node == dest:
        return node
    frontier = Queue()
    frontier.push((node,[node]))
    reached = set()
    nodeTuple = node.to_tuple()
    reached.add(nodeTuple)
    expanded = 0
    while not frontier.isEmpty():
        expanded += 1
        node, path = frontier.pop()
        for child in expand(node,epolygons): #write expand function after writing functions to check if point is in polygon
            if child == dest:      #you cant include invalid points in the expansion
                print(expanded)
                return path + [child]
            childTuple = child.to_tuple()
            if childTuple not in reached:
                reached.add(childTuple)
                frontier.push((child,path + [child]))
    return None

def gbfs(source,dest,epolygons):
    node = source
    frontier = PriorityQueue()
    f = heuristic(source,dest)
    frontier.push((node,[node]),f) 
    sourceTuple = source.to_tuple()
    reached = {sourceTuple: [node]}
    expanded = 0
    while not frontier.isEmpty():
        expanded += 1
        (node,path) = frontier.pop()
        if node == dest:
            print(expanded)
            return path
        for child in expand(node,epolygons):
            s = child
            sTuple = s.to_tuple()
            if sTuple not in reached:
                reached[sTuple] = path + [s]
                f = heuristic(s,dest)
                frontier.push((s,path + [s]),f)
    return None

def aStar(source,dest,epolygons,tpolygons):
    frontier = PriorityQueue()
    g = 0 #initial path cost
    f = g + heuristic(source,dest)
    frontier.push((source,[source]),f)
    sourceTuple = source.to_tuple()
    reached = {sourceTuple: (g,[source])}
    expanded = 0
    while not frontier.isEmpty():
        expanded += 1
        node,path = frontier.pop()
        nodeTuple = node.to_tuple()
        g = reached[nodeTuple][0]
        if node == dest:
            print(expanded)
            return path
        for child in expand(node,epolygons):
            s = child
            sTuple = s.to_tuple()
            newG = g + actionCost(node,s,tpolygons)
            newF = newG + heuristic(s,dest)
            if sTuple not in reached or newG < reached[sTuple][0]:
                reached[sTuple] = (newG, path + [s])
                frontier.push((s, path + [s]), newF)
    return None

def inPolygon(point,polygon): #determine if point is in polygon
    verticies = len(polygon)
    x,y = point.to_tuple()
    inside = False
    p1 = polygon[0]
    for i in range(1,verticies+1):
        p2 = polygon[i % verticies]
        if (min(p1.x, p2.x) <= x <= max(p1.x, p2.x) and min(p1.y, p2.y) <= y <= max(p1.y, p2.y)): #checking if point is on the edge
            if p1.y == p2.y and y == p1.y and x <= max(p1.x, p2.x):
                return True
            if p1.x == p2.x and x == p1.x and y <= max(p1.y, p2.y):
                return True
            if ((y - p1.y) * (p2.x - p1.x) == (p2.y - p1.y) * (x - p1.x)):
                return True
        if p1.y == p2.y: #skip horizontal edges to avoid division by zero error
            p1 = p2
            continue
        if y > min(p1.y,p2.y): #checking if point is inside
            if y <= max(p1.y,p2.y):
                if x <= max(p1.x,p2.x):
                    xIntersection = (y - p1.y) * (p2.x - p1.x) / (p2.y - p1.y) + p1.x
                    if p1.x == p2.x or x <= xIntersection:
                        inside = not inside
        p1 = p2
    return inside
    
def checkTurf(point,tpolygons):
    for polygon in tpolygons:
        if inPolygon(point,polygon):
            return True
    return False

def expand(node,epolygons): 
    x, y = node.to_tuple()
    directions = [(0, 1), (1, 0), (0, -1), (-1, 0)]  
    children = []
    for dx, dy in directions:
        new_x, new_y = x + dx, y + dy
        new_point = Point(new_x, new_y)
        if 0 <= new_x < 50 and 0 <= new_y < 50:
            outside_all_polygons = True
            for polygon in epolygons:  
                if inPolygon(new_point, polygon):  
                    outside_all_polygons = False
                    break
            if outside_all_polygons:
                children.append(new_point)
    return children

def actionCost(p,pPrime,tpolygons): 
    if checkTurf(pPrime,tpolygons):
        return 1.5 
    return 1

def heuristic(p1,p2):
    return ((p1.x - p2.x) ** 2 + (p1.y - p2.y) ** 2) ** 0.5

def calculateCost(path, tpolygons):
    cost = 0
    for i in range(len(path) - 1):
        cost += actionCost(path[i], path[i + 1], tpolygons)
    return cost