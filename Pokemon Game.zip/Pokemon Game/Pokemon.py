import random
import csv
import ast
import math
class Pokemon:
    def __init__(self,name):
        self.name = name
        self.usedMoves = {}
    def getPokemonInfo(self): #gets all the pokemon as the key and the element is their list of moves
        pokemonDict = {}
        with open('pokemon-data.csv') as csvfile:
            reader = csv.reader(csvfile, delimiter=',')
            header = next(reader)
            for row in reader:
                pokemonDict[row[0]] = row[7]
        return pokemonDict
    def coinToss(self):
        coin = random.randint(0,1)
        if coin == 0:
            return "Team Rocket"
        else:
            return "Team " + self.name
    def getTeam(self,userTeam,rocketTeam,infoDict):
        l1set = set()     #using these sets to ensure no duplicates
        l2set = set()
        while len(l1set) < 3:
            l1set.add(random.choice(list(infoDict.keys())))
        while len(l2set) < 3:
            l2set.add(random.choice(list(infoDict.keys())))
        userTeam.extend(list(l1set))
        rocketTeam.extend(list(l2set))
    def attack(self,turn,attacker,defender,infoDict,pokemonHealth):
        move = ''
        if turn != 'rocket':
            moves = ast.literal_eval(infoDict[attacker]) 
            if attacker not in self.usedMoves:
                self.usedMoves[attacker] = set()
            availableMoves = [move for move in moves if move not in self.usedMoves[attacker]] #ensures a move cant be reused unless all moves are used
            if not availableMoves:
                self.usedMoves[attacker].clear()
                availableMoves = moves
            print('Choose move for ' + attacker + ':')
            for i,move in enumerate(availableMoves,1):
                print(f'{i}. {move}')
            while True:
                attackChoice = input('Team ' + turn + ' choice:')
                print('\n')
                try:
                    attackChoice = int(attackChoice)
                    if 1 <= attackChoice <= len(availableMoves):
                        move = availableMoves[attackChoice-1]
                        self.usedMoves[attacker].add(move)
                        break
                    else:
                        print('Invalid choice. Please choose a number between 1 and ' + str(len(availableMoves)) + '.')
                except ValueError:
                    print('Invalid input. Please enter a number.')  
            damage = self.calculateDamage(move,attacker,defender) 
            pokemonHealth[defender] = pokemonHealth[defender] - damage #tracking HP
            print(attacker + ' cast '+ move + ' to ' + defender + ':')
            print('Damage to ' + defender + ' is ' + str(damage) + ' points.')
            if pokemonHealth[defender] <= 0:
                print('Now ' + attacker + ' has ' + str(pokemonHealth[attacker]) + ' HP, and ' + defender + ' has fainted!')
                print('\n')
                pokemonHealth[defender] = 0
            else:
                print('Now ' + defender + ' has ' + str(pokemonHealth[defender]) + ' HP, and ' + attacker + ' has ' + str(pokemonHealth[attacker]) + ' HP.')
                print('\n')
        else: #if its team rockets turn
            moves = ast.literal_eval(infoDict[attacker])
            move += random.choice(moves)
            damage = self.calculateDamage(move,attacker,defender) #fill in logic for damage calculation
            pokemonHealth[defender] = pokemonHealth[defender] - damage
            print("Team Rocket's " + attacker + ' cast ' + move + ' to ' + defender + ':')
            print('Damage to ' + defender + ' is ' + str(damage) + ' points.')
            if pokemonHealth[defender] <= 0:
                print('Now ' + attacker + ' has ' + str(pokemonHealth[attacker]) + ' HP, and ' + defender + ' has fainted!')
                print('\n')
                pokemonHealth[defender] = 0
            else:
                print('Now ' + defender + ' has ' + str(pokemonHealth[defender]) + ' HP, and ' + attacker + ' has ' + str(pokemonHealth[attacker]) + ' HP.')
                print('\n')
    def getHP(self,pokemon):
        with open('pokemon-data.csv') as csvfile:
            reader = csv.reader(csvfile, delimiter=',')
            header = next(reader)
            for row in reader:
                if row[0] == pokemon:
                    return row[2]
    def calculateDamage(self,move,attacker,defender):
        with open('moves-data.csv') as csvfile:
            reader = csv.DictReader(csvfile)
            for row in reader:
                if row['Name'] == move:
                    power = int(row['Power'])
                    moveType = row['Type']
                    break
        with open('pokemon-data.csv') as csvfile:
            reader = csv.DictReader(csvfile)
            for row in reader:
                if row['Name'] == attacker:
                    attack = int(row['Attack'])
                    attackerType = row['Type']
                if row['Name'] == defender:
                    defense = int(row['Defense'])
                    defenderType = row['Type']
        stab = 1.5 if moveType == attackerType else 1
        typeEfficiency = self.getTypeEfficiency(moveType,defenderType) 
        randomFactor = random.uniform(0.5,1.0)
        damage = power * attack / defense * stab * typeEfficiency * randomFactor #damage calculation
        return math.ceil(damage)
    def getTypeEfficiency(self,moveType,defenderType):
        typeChart = {
            'Normal': {'Normal': 1, 'Fire': 1, 'Water': 1, 'Electric': 1, 'Grass': 1},
            'Fire': {'Normal': 1, 'Fire': 0.5, 'Water': 0.5, 'Electric': 1, 'Grass': 2},
            'Water': {'Normal': 1, 'Fire': 2, 'Water': 0.5, 'Electric': 1, 'Grass': 0.5},
            'Electric': {'Normal': 1, 'Fire': 1, 'Water': 2, 'Electric': 0.5, 'Grass': 0.5}, #chart from documentation
            'Grass': {'Normal': 1, 'Fire': 0.5, 'Water': 2, 'Electric': 1, 'Grass': 0.5},
            'Others': {'Normal': 1, 'Fire': 1, 'Water': 1, 'Electric': 1, 'Grass': 1}
        }
        return typeChart.get(moveType,{}).get(defenderType,1)