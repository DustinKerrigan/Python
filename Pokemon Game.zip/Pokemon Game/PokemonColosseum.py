from Pokemon import Pokemon

print('Welcome to Pokemon Colosseum!')
print('\n')
playerName = input('Enter Player Name: ')
pokemon = Pokemon(playerName)
infoDict = pokemon.getPokemonInfo()
userTeam = []
rocketTeam = []
pokemon.getTeam(userTeam,rocketTeam,infoDict)
print('\n')
print('Team Rocket enters with ' + rocketTeam[0] + ', ' + rocketTeam[1] + ', and ' + rocketTeam[2] + '.') 
print('\n')
print('Team ' + playerName + ' enters with ' + userTeam[0] + ', ' + userTeam[1] + ', and ' + userTeam[2] + '.') 
print('\n')
print('Let the battle begin!')
firstTurn = pokemon.coinToss()
print('Coin toss goes to ---- ' + firstTurn + ' to start the attack!')
print('\n')
isRocketsTurn = (firstTurn == 'Team Rocket')
winner,loser = '',''
userTeam = userTeam[::-1]
rocketTeam = rocketTeam[::-1]
pokemonHealth = {}
for item in infoDict.keys():
    pokemonHealth[item] = int(pokemon.getHP(item))
while True: #game flow
    if isRocketsTurn:
        pokemon.attack('rocket',rocketTeam[len(rocketTeam)-1],userTeam[len(userTeam)-1],infoDict,pokemonHealth)
        if pokemonHealth[userTeam[len(userTeam)-1]] <= 0:
            userTeam.pop()
            if len(userTeam) == 0:
                winner+= 'Team Rocket'
                loser += 'Team ' + playerName
                break
            else:
                print('Next for Team ' + playerName + ', ' + userTeam[len(userTeam)-1] + ' enters the battle!')
                print('\n')
    else:             #(attacker,defender) #users turn
        pokemon.attack(playerName,userTeam[len(userTeam)-1],rocketTeam[len(rocketTeam)-1],infoDict,pokemonHealth)
        if pokemonHealth[rocketTeam[len(rocketTeam)-1]] <= 0:
            rocketTeam.pop()
            if len(rocketTeam) == 0:
                winner+= 'Team ' + playerName
                loser += 'Team Rocket'
                break
            else:
                print('Next for Team Rocket, ' + rocketTeam[len(rocketTeam)-1] + ' enters the battle!')
                print('\n')
    isRocketsTurn = not isRocketsTurn
print('\n')
print('All of ' + loser + "'s Pokemon have fainted, and " + winner + ' prevails!')
    