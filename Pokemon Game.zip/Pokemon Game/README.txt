# CAP4630 Project 1

## Description
This project is designed to replicate a Pokemon Battle.

## Requirements
- Python 3.11
-Random
-ast
-csv
-math

## Instructions
To run this program, run the python PokemonColosseum.py command. Enter your preferred team name, and begin playing the game. Make sure
you have random,ast,csv, and math installed and imported. 
